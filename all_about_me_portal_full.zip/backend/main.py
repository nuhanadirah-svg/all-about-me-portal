import csv
import io
import os
from datetime import datetime, timezone
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from pydantic import BaseModel, Field
from pymongo import MongoClient

load_dotenv()

MONGO_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGODB_DB", "all_about_me")
PASSCODE = os.getenv("TEACHER_PASSCODE", "CHANGE_ME")
SECRET = os.getenv("SESSION_SECRET", "change-me-in-production")
ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]

app = FastAPI(title="All About Me Portal API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
pupils = db.pupils
reflections = db.reflections
forum = db.forum
resources = db.resources

serializer = URLSafeTimedSerializer(SECRET)

ACTIVITIES = [
    "padlet-preassessment", "activity-1", "activity-2",
    "activity-3", "activity-4", "wayground-quiz", "exit-ticket"
]

DEFAULT_RESOURCES = {
    "lesson_video": "https://drive.google.com/file/d/1xWv4HNaxfX2JlGOy7X31g-5OOthNojcZ/view?usp=drivesdk",
    "padlet": "https://padlet.com/nurnuhanadirah/knowing-yourself-s0247jp0cga3y81zbvv5",
    "canva_prompt_cards": "https://canva.link/xd9eqavnuh42xio",
    "canva_poster_gallery": "https://canva.link/ta6aax0ho7moo74",
    "canva_peer_feedback": "https://canva.link/2bnw2ro626ruf2p",
    "wayground": "https://wayground.com/join/quiz/6ac4c3b9ee57efc12393ab95/start?studentShare=true",
    "external_game": "",
    "exit_ticket": "https://canva.link/fjszx14hls9s51y",
    "media_effectiveness": "https://kami.app/7ja-5np-6tC-DQy",
}

class Profile(BaseModel):
    nickname: str = Field(min_length=1, max_length=30)
    star: dict = {}

class ActivityBody(BaseModel):
    activity_id: str
    completed: bool = True

class QuizBody(BaseModel):
    score: float
    total: float

class ReflectionBody(BaseModel):
    mood: str = ""
    response: str = ""
    media_rating: Optional[int] = None

class LoginBody(BaseModel):
    passcode: str

class ResourceBody(BaseModel):
    url: str = ""

class ForumBody(BaseModel):
    nickname: str
    message: str = Field(min_length=1, max_length=1000)

def now():
    return datetime.now(timezone.utc)

def clean_name(name: str):
    return " ".join(name.strip().split())[:30]

def teacher_ok(request: Request):
    token = request.cookies.get("teacher_session")
    if not token:
        raise HTTPException(401, "Teacher login required")
    try:
        serializer.loads(token, max_age=60*60*8)
    except (BadSignature, SignatureExpired):
        raise HTTPException(401, "Teacher session expired")

def pupil_doc(nickname):
    return pupils.find_one({"nickname": nickname}, {"_id": 0})

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/pupils")
def save_profile(p: Profile):
    nickname = clean_name(p.nickname)
    if not nickname:
        raise HTTPException(400, "Nickname required")
    existing = pupil_doc(nickname)
    base = existing or {
        "nickname": nickname,
        "activities": {},
        "stars": 0,
        "quiz": None,
        "created_at": now().isoformat(),
    }
    base["star"] = p.star
    base["updated_at"] = now().isoformat()
    pupils.replace_one({"nickname": nickname}, base, upsert=True)
    return pupil_doc(nickname)

@app.get("/api/pupils/{nickname}")
def get_profile(nickname: str):
    doc = pupil_doc(nickname)
    if not doc:
        raise HTTPException(404, "Pupil not found")
    return doc

@app.post("/api/pupils/{nickname}/activities")
def activity(nickname: str, body: ActivityBody):
    if body.activity_id not in ACTIVITIES:
        raise HTTPException(400, "Unknown activity")
    doc = pupil_doc(nickname)
    if not doc:
        raise HTTPException(404, "Pupil not found")
    activities = doc.get("activities", {})
    if not activities.get(body.activity_id):
        activities[body.activity_id] = True
    stars = sum(1 for x in ACTIVITIES if activities.get(x))
    pupils.update_one({"nickname": nickname}, {"$set": {
        "activities": activities, "stars": stars, "updated_at": now().isoformat()
    }})
    return pupil_doc(nickname)

@app.post("/api/pupils/{nickname}/quiz")
def quiz(nickname: str, body: QuizBody):
    pupils.update_one({"nickname": nickname}, {"$set": {
        "quiz": {"score": body.score, "total": body.total, "updated_at": now().isoformat()}
    }})
    return pupil_doc(nickname)

@app.post("/api/pupils/{nickname}/reflection")
def reflection(nickname: str, body: ReflectionBody):
    doc = {"nickname": nickname, "mood": body.mood, "response": body.response,
           "media_rating": body.media_rating, "created_at": now().isoformat()}
    reflections.insert_one(doc)
    doc.pop("_id", None)
    return doc

@app.get("/api/forum")
def get_forum():
    return list(forum.find({}, {"_id": 0}).sort("created_at", -1).limit(100))

@app.post("/api/forum")
def post_forum(body: ForumBody):
    doc = {"nickname": clean_name(body.nickname), "message": body.message.strip(),
           "created_at": now().isoformat(), "approved": True}
    forum.insert_one(doc)
    doc.pop("_id", None)
    return doc

@app.delete("/api/forum/{created_at}")
def delete_forum(created_at: str, request: Request):
    teacher_ok(request)
    forum.delete_one({"created_at": created_at})
    return {"ok": True}

@app.post("/api/teacher/login")
def teacher_login(body: LoginBody):
    if body.passcode != PASSCODE:
        raise HTTPException(401, "Incorrect passcode")
    token = serializer.dumps({"teacher": True})
    response = StreamingResponse(iter([b'{"ok":true}']), media_type="application/json")
    response.set_cookie("teacher_session", token, httponly=True, samesite="lax", secure=False, max_age=60*60*8)
    return response

@app.post("/api/teacher/logout")
def teacher_logout():
    response = StreamingResponse(iter([b'{"ok":true}']), media_type="application/json")
    response.delete_cookie("teacher_session")
    return response

@app.get("/api/teacher/pupils")
def teacher_pupils(request: Request):
    teacher_ok(request)
    return list(pupils.find({}, {"_id": 0}).sort("updated_at", -1))

@app.get("/api/teacher/reflections")
def teacher_reflections(request: Request):
    teacher_ok(request)
    return list(reflections.find({}, {"_id": 0}).sort("created_at", -1))

@app.get("/api/resources")
def get_resources():
    saved = {r["key"]: r.get("url", "") for r in resources.find({}, {"_id": 0, "key": 1, "url": 1})}
    return {**DEFAULT_RESOURCES, **saved}

@app.put("/api/resources/{key}")
def put_resource(key: str, body: ResourceBody, request: Request):
    teacher_ok(request)
    resources.update_one({"key": key}, {"$set": {"key": key, "url": body.url}}, upsert=True)
    return {"key": key, "url": body.url}

@app.get("/api/teacher/export.csv")
def export_csv(request: Request):
    teacher_ok(request)
    rows = list(pupils.find({}, {"_id": 0}))
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Nickname", "Stars", "Quiz Score", "Quiz Total", *ACTIVITIES])
    for r in rows:
        q = r.get("quiz") or {}
        writer.writerow([r.get("nickname",""), r.get("stars",0), q.get("score",""), q.get("total",""),
                         *["Yes" if r.get("activities",{}).get(a) else "No" for a in ACTIVITIES]])
    data = out.getvalue().encode("utf-8")
    return StreamingResponse(io.BytesIO(data), media_type="text/csv",
                             headers={"Content-Disposition":"attachment; filename=all-about-me-results.csv"})

@app.post("/api/teacher/start-fresh")
def start_fresh(request: Request):
    teacher_ok(request)
    pupils.delete_many({})
    reflections.delete_many({})
    return {"ok": True}
