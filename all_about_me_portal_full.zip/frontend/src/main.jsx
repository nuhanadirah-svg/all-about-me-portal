import React, {useEffect, useMemo, useRef, useState} from "react";
import {createRoot} from "react-dom/client";
import * as THREE from "three";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

const RES = {
 lesson_video:"https://drive.google.com/file/d/1xWv4HNaxfX2JlGOy7X31g-5OOthNojcZ/view?usp=drivesdk",
 padlet:"https://padlet.com/nurnuhanadirah/knowing-yourself-s0247jp0cga3y81zbvv5",
 canva_prompt_cards:"https://canva.link/xd9eqavnuh42xio",
 canva_poster_gallery:"https://canva.link/ta6aax0ho7moo74",
 canva_peer_feedback:"https://canva.link/2bnw2ro626ruf2p",
 wayground:"https://wayground.com/join/quiz/6ac4c3b9ee57efc12393ab95/start?studentShare=true",
 exit_ticket:"https://canva.link/fjszx14hls9s51y",
 media_effectiveness:"https://kami.app/7ja-5np-6tC-DQy"
};

const ACTIVITIES=[
 ["padlet-preassessment","Padlet Pre-Assessment","Tell us what you already know."],
 ["activity-1","Activity 1: My Identity","Explore words that describe you."],
 ["activity-2","Activity 2: My Feelings","Connect words and feelings."],
 ["activity-3","Activity 3: My Mini-Poster","Create and share a mini-poster."],
 ["activity-4","Activity 4: Peer Feedback","Give kind feedback to a friend."],
 ["wayground-quiz","Quiz Time","Check what you have learned."],
 ["exit-ticket","Exit Ticket","Tell us what you are taking away."]
];

function iframeUrl(url){
 if(!url) return "";
 if(url.includes("drive.google.com/file/d/")){
   const m=url.match(/\/d\/([^/]+)/); return m?`https://drive.google.com/file/d/${m[1]}/preview`:url;
 }
 return url;
}

function Star3D({color="#F5A3C7",size=210,spin=true}){
 const mount=useRef(null);
 useEffect(()=>{
  const el=mount.current; if(!el) return;
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(30,1,.1,100); camera.position.z=5;
  const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(size,size); el.appendChild(renderer.domElement);
  const group=new THREE.Group(); scene.add(group);
  const shape=new THREE.Shape(), spikes=5, outer=1.25, inner=.62;
  for(let i=0;i<spikes*2;i++){const a=i*Math.PI/spikes-Math.PI/2,r=i%2?inner:outer;const x=Math.cos(a)*r,y=Math.sin(a)*r;i?shape.lineTo(x,y):shape.moveTo(x,y);}
  shape.closePath();
  const geo=new THREE.ExtrudeGeometry(shape,{depth:.38,bevelEnabled:true,bevelSegments:4,bevelSize:.12,bevelThickness:.1});
  const mat=new THREE.MeshStandardMaterial({color,roughness:.25,metalness:.05});
  const mesh=new THREE.Mesh(geo,mat); group.add(mesh);
  const eyeMat=new THREE.MeshStandardMaterial({color:"#252525"});
  [-.32,.32].forEach(x=>{const e=new THREE.Mesh(new THREE.SphereGeometry(.07,16,16),eyeMat);e.position.set(x,.12,.27);group.add(e)});
  const smile=new THREE.Mesh(new THREE.TorusGeometry(.14,.025,8,24,Math.PI),eyeMat); smile.rotation.x=Math.PI/2; smile.position.z=.28; smile.position.y=-.12; group.add(smile);
  const light=new THREE.DirectionalLight("#ffffff",2);light.position.set(2,3,4);scene.add(light);scene.add(new THREE.AmbientLight("#ffffff",1.2));
  let id; const animate=()=>{if(spin)group.rotation.y+=.008;renderer.render(scene,camera);id=requestAnimationFrame(animate)};animate();
  return()=>{cancelAnimationFrame(id);renderer.dispose();geo.dispose();mat.dispose();el.innerHTML=""}
 },[color,size,spin]);
 return <div ref={mount} className="star3d" style={{width:size,height:size}}/>;
}

function CompleteButton({id,done,onComplete}){
 return <button className={done?"done-btn":"primary"} onClick={()=>onComplete(id)}>{done?"✓ Completed":"I finished this! ⭐"}</button>
}

function Resource({title,url}){
 return <section className="resource"><div className="resource-head"><h3>{title}</h3>{url&&<a href={url} target="_blank" rel="noreferrer">Open ↗</a>}</div>
 {url?<iframe src={iframeUrl(url)} title={title} loading="lazy" allow="autoplay; fullscreen" />:<div className="fallback">Resource link not added yet.</div>}</section>
}

function App(){
 const [page,setPage]=useState("dashboard");
 const [nickname,setNickname]=useState(localStorage.getItem("nickname")||"");
 const [star,setStar]=useState(JSON.parse(localStorage.getItem("star")||'{"color":"#F5A3C7","surface":"jelly","accessory":"none","pattern":"sparkles"}'));
 const [profile,setProfile]=useState(null);
 const [resources,setResources]=useState(RES);
 const [soundOn,setSoundOn]=useState(localStorage.getItem("soundOn")==="true");
 const [volume,setVolume]=useState(Number(localStorage.getItem("soundVolume")||0.28));
 const [reduced,setReduced]=useState(false);
 const audio=useRef(null);

 useEffect(()=>{fetch(`${API}/api/resources`).then(r=>r.json()).then(setResources).catch(()=>{})},[]);
 useEffect(()=>{
   if(audio.current){audio.current.volume=volume; if(soundOn) audio.current.play().catch(()=>{}); else audio.current.pause();}
   localStorage.setItem("soundOn",soundOn); localStorage.setItem("soundVolume",volume);
 },[soundOn,volume]);
 useEffect(()=>{
   if(!audio.current)return;
   const play=()=>{if(soundOn)audio.current.play().catch(()=>{})};
   window.addEventListener("pointerdown",play,{once:true}); return()=>window.removeEventListener("pointerdown",play);
 },[soundOn]);

 async function saveProfile(nextNickname=nickname,nextStar=star){
   const p=await fetch(`${API}/api/pupils`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({nickname:nextNickname,star:nextStar})}).then(r=>r.json());
   setProfile(p);setNickname(nextNickname);setStar(nextStar);localStorage.setItem("nickname",nextNickname);localStorage.setItem("star",JSON.stringify(nextStar));
 }
 async function loadProfile(name=nickname){
   if(!name)return; const r=await fetch(`${API}/api/pupils/${encodeURIComponent(name)}`);
   if(r.ok)setProfile(await r.json());
 }
 async function complete(id){
   if(!nickname)return setPage("studio");
   const r=await fetch(`${API}/api/pupils/${encodeURIComponent(nickname)}/activities`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({activity_id:id,completed:true})});
   if(r.ok)setProfile(await r.json());
 }
 async function quiz(score,total){
   if(!nickname)return; const r=await fetch(`${API}/api/pupils/${encodeURIComponent(nickname)}/quiz`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({score,total})}); if(r.ok)setProfile(await r.json());
 }
 async function reflection(data){
   if(!nickname)return; await fetch(`${API}/api/pupils/${encodeURIComponent(nickname)}/reflection`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)}); complete("exit-ticket");
 }
 const done=id=>!!profile?.activities?.[id];
 const stars=profile?.stars||0;
 const all=stars===7;

 return <div className="app">
   <audio ref={audio} loop preload="none"><source src="/audio/aesthetic-background.mp3" type="audio/mpeg"/></audio>
   <div className="sky-decor"><span>✦</span><span>✧</span><span>✦</span><span>✧</span><span>✦</span></div>
   <header className="topbar">
    <button className="brand" onClick={()=>setPage("dashboard")}>⭐ ALL ABOUT ME</button>
    <nav>{["dashboard","objectives","activities","quiz","reflection","forum","settings"].map(x=><button key={x} className={page===x?"nav-active":""} onClick={()=>setPage(x)}>{x==="dashboard"?"Dashboard":x==="objectives"?"Learning Objectives":x==="activities"?"Activities":x==="quiz"?"Quiz":x==="reflection"?"Reflection Task":x==="forum"?"Forum":"Settings"}</button>)}</nav>
    <div className="top-actions"><span className="counter">⭐ {stars}/7</span><button className="sound-mini" onClick={()=>setSoundOn(v=>!v)}>{soundOn?"🔊":"🔇"}</button><button onClick={()=>setPage("teacher")}>Teacher</button></div>
   </header>

   <main>
    {page==="dashboard"&&<Dashboard nickname={nickname} profile={profile} all={all} onStudio={()=>setPage("studio")} onGo={setPage} reduced={reduced}/>}
    {page==="studio"&&<Studio nickname={nickname} star={star} save={saveProfile} onBack={()=>setPage("dashboard")}/>}
    {page==="objectives"&&<Objectives/>}
    {page==="activities"&&<Activities profile={profile} done={done} complete={complete} resources={resources} onQuiz={()=>setPage("quiz")}/>}
    {page==="quiz"&&<Quiz profile={profile} done={done} complete={complete} submit={quiz} url={resources.wayground}/>}
    {page==="reflection"&&<Reflection submit={reflection}/>}
    {page==="forum"&&<Forum nickname={nickname}/>}
    {page==="settings"&&<Settings soundOn={soundOn} setSoundOn={setSoundOn} volume={volume} setVolume={setVolume} reduced={reduced} setReduced={setReduced}/>}
    {page==="teacher"&&<Teacher onBack={()=>setPage("dashboard")}/>}
   </main>
   <footer>ALL ABOUT ME · Year 5 English · Be kind, be curious, be yourself ✨</footer>
 </div>
}

function Dashboard({nickname,profile,all,onStudio,onGo,reduced}){
 const first=!nickname;
 return <div className="page hero-page">
  <div className="hero-copy"><p className="eyebrow">WELCOME TO YOUR STAR MAP</p><h1>ALL ABOUT ME</h1><p>Discover words, feelings and ideas that make you wonderfully you.</p>
   <div className="hero-buttons"><button className="primary" onClick={onStudio}>{first?"Create My Star":"Edit My Star"} ✨</button><button className="secondary" onClick={()=>onGo("activities")}>Start Learning →</button></div>
  </div>
  <div className="hero-star"><Star3D color={profile?.star?.color||"#F5A3C7"} spin={!reduced}/><div className="speech">{nickname?`Hi ${nickname}! Let's learn together!`:"Hi! Let's create your star!"}</div></div>
  <section className="star-map"><h2>🌈 Your Star Map</h2><div className="path">{ACTIVITIES.map((a,i)=><div className={`mission ${profile?.activities?.[a[0]]?"collected":""}`} key={a[0]}><div className="mission-star">{profile?.activities?.[a[0]]?"⭐":"☆"}</div><div><b>{i+1}. {a[1]}</b><small>{a[2]}</small></div></div>)}</div>{all&&<div className="celebrate">🎉 You collected all 7 stars! Amazing work!</div>}</section>
 </div>
}

function Studio({nickname,star,save,onBack}){
 const [n,setN]=useState(nickname); const [s,setS]=useState(star);
 const colours=["#F5A3C7","#FFD96B","#C9A8E8","#8EDDE6","#9FB1F0"];
 return <div className="page"><button onClick={onBack}>← Back</button><div className="studio-grid"><div className="card studio-card"><p className="eyebrow">STAR STUDIO</p><h1>Create your own 3D Star</h1><p>Use a first name or nickname only.</p><label>Nickname<input value={n} maxLength="30" onChange={e=>setN(e.target.value)}/></label>
 <label>Body colour<div className="colour-row">{colours.map(c=><button aria-label={c} key={c} className="colour-dot" style={{background:c}} onClick={()=>setS({...s,color:c})}/>)}</div></label>
 <label>Surface<select value={s.surface} onChange={e=>setS({...s,surface:e.target.value})}><option>jelly</option><option>glitter</option><option>matte clay</option></select></label>
 <label>Accessory<select value={s.accessory} onChange={e=>setS({...s,accessory:e.target.value})}><option>none</option><option>bow</option><option>hat</option><option>glasses</option><option>crown</option><option>headphones</option></select></label>
 <label>Pattern<select value={s.pattern} onChange={e=>setS({...s,pattern:e.target.value})}><option>sparkles</option><option>stripes</option><option>plain</option></select></label>
 <button className="primary" onClick={()=>save(n,s)}>Save my star ⭐</button></div><div className="card preview-card"><Star3D color={s.color}/><h2>{n||"Your Star"}</h2><p>{s.surface} · {s.accessory} · {s.pattern}</p></div></div></div>
}

function Objectives(){return <div className="page"><div className="card wide"><p className="eyebrow">LEARNING OBJECTIVES</p><h1>By the end of this lesson, I can…</h1><div className="objective-grid"><div><b>Content Standard</b><p>Language Arts: respond to and enjoy stories, poems and other creative texts.</p></div><div><b>Learning Standard</b><p>Say in simple words and phrases how a text makes them feel.</p></div><div><b>Success looks like</b><p>I can use simple English to describe myself, my feelings and my response to a text.</p></div></div></div></div>}

function Activities({profile,done,complete,resources,onQuiz}){
 return <div className="page"><div className="card wide"><p className="eyebrow">LET'S DO ACTIVITIES</p><h1>Follow the rainbow path 🌈</h1><div className="activity-list">
  <div className="activity-card"><span className="badge">START</span><h2>Meet Teacher's Alter-Ego</h2><Resource title="Lesson Video" url={resources.lesson_video}/><Resource title="Padlet Pre-Assessment" url={resources.padlet}/><CompleteButton id="padlet-preassessment" done={done("padlet-preassessment")} onComplete={complete}/></div>
  <ActivityCard n="1" title="My Identity" url={resources.canva_prompt_cards} text="Use the prompt cards and bubble map to explore words about yourself." id="activity-1" done={done("activity-1")} complete={complete}/>
  <ActivityCard n="2" title="My Feelings" url={resources.canva_poster_gallery} text="Look at the examples and connect feelings with your own experiences." id="activity-2" done={done("activity-2")} complete={complete}/>
  <ActivityCard n="3" title="My Mini-Poster" url={resources.canva_poster_gallery} text="Create a simple personal mini-poster." id="activity-3" done={done("activity-3")} complete={complete}/>
  <ActivityCard n="4" title="Peer Feedback" url={resources.canva_peer_feedback} text="Give one kind and useful response to a classmate." id="activity-4" done={done("activity-4")} complete={complete}/>
 </div><button className="primary" onClick={onQuiz}>Go to Quiz →</button></div></div>
}

function ActivityCard({n,title,url,text,id,done,complete}){return <div className="activity-card"><span className="badge">ACTIVITY {n}</span><h2>{title}</h2><p>{text}</p><Resource title={`${title} resource`} url={url}/><CompleteButton id={id} done={done} onComplete={complete}/></div>}

function Quiz({profile,done,complete,submit,url}){
 const [answers,setAnswers]=useState({q1:"",q2:""}); const [score,setScore]=useState(null);
 function mark(){let s=0;if(answers.q1==="happy")s+=50;if(answers.q2==="kind")s+=50;setScore(s);submit(s,100);complete("wayground-quiz")}
 return <div className="page"><div className="card quiz-card"><p className="eyebrow">QUIZ TIME</p><h1>Show what you know ⭐</h1><p>You can also open the teacher-provided Wayground quiz.</p><a className="link-button" href={url} target="_blank" rel="noreferrer">Open Wayground Quiz ↗</a>
 <div className="question"><b>1. If a story makes you smile, you might feel…</b><label><input type="radio" name="q1" onChange={()=>setAnswers({...answers,q1:"happy"})}/> happy</label><label><input type="radio" name="q1" onChange={()=>setAnswers({...answers,q1:"sad"})}/> sad</label></div>
 <div className="question"><b>2. Good peer feedback should be…</b><label><input type="radio" name="q2" onChange={()=>setAnswers({...answers,q2:"kind"})}/> kind</label><label><input type="radio" name="q2" onChange={()=>setAnswers({...answers,q2:"mean"})}/> mean</label></div>
 <button className="primary" onClick={mark}>Submit Quiz</button>
 {score!==null&&<div className="result">{score>=50?"Good job! 🎉":"Almost there! Keep practising. 🌱"} Score: {score}/100</div>}</div></div>
}

function Reflection({submit}){const [mood,setMood]=useState("");const [response,setResponse]=useState("");const [rating,setRating]=useState(5);const [sent,setSent]=useState(false);return <div className="page"><div className="card wide"><p className="eyebrow">REFLECTION TASK</p><h1>How did this lesson feel?</h1><label>My mood<select value={mood} onChange={e=>setMood(e.target.value)}><option value="">Choose one</option><option>😊 Happy</option><option>🙂 Calm</option><option>🤔 Curious</option><option>😮 Surprised</option></select></label><label>One thing I learned<textarea value={response} onChange={e=>setResponse(e.target.value)} placeholder="Write a short sentence…"/></label><label>How helpful was the digital media? <input type="range" min="1" max="5" value={rating} onChange={e=>setRating(Number(e.target.value))}/><b>{rating}/5</b></label><button className="primary" onClick={async()=>{await submit({mood,response,media_rating:rating});setSent(true)}}>Send Reflection ⭐</button>{sent&&<div className="result">Thank you for reflecting! ✨</div>}</div></div>}

function Forum({nickname}){const [posts,setPosts]=useState([]);const [msg,setMsg]=useState("");async function load(){const r=await fetch(`${API}/api/forum`);if(r.ok)setPosts(await r.json())}useEffect(()=>{load()},[]);async function send(){if(!nickname||!msg.trim())return;await fetch(`${API}/api/forum`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({nickname,message:msg})});setMsg("");load()}return <div className="page"><div className="card wide"><p className="eyebrow">FORUM</p><h1>Share kindly 💬</h1><p>Use respectful words. Do not share private information.</p><textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Write a kind comment…"/><button className="primary" onClick={send}>Post</button><div className="forum-list">{posts.map((p,i)=><article key={i}><b>{p.nickname}</b><p>{p.message}</p></article>)}</div></div></div>}

function Settings({soundOn,setSoundOn,volume,setVolume,reduced,setReduced}){return <div className="page"><div className="card settings-card"><p className="eyebrow">SETTINGS</p><h1>Make the portal comfortable for you ⚙️</h1><div className="setting-row"><div><b>Background aesthetic sound</b><p>Sound is off by default. Add your own royalty-free MP3 to <code>/public/audio/aesthetic-background.mp3</code>.</p></div><button className={soundOn?"toggle on":"toggle"} onClick={()=>setSoundOn(!soundOn)}>{soundOn?"ON":"OFF"}</button></div><label>Volume <input type="range" min="0" max="1" step=".01" value={volume} onChange={e=>setVolume(Number(e.target.value))}/><span>{Math.round(volume*100)}%</span></label><div className="setting-row"><div><b>Reduced motion</b><p>Slows or removes decorative movement.</p></div><button className={reduced?"toggle on":"toggle"} onClick={()=>setReduced(!reduced)}>{reduced?"ON":"OFF"}</button></div></div></div>}

function Teacher({onBack}){const [pass,setPass]=useState("");const [ok,setOk]=useState(false);const [pupils,setPupils]=useState([]);const [refs,setRefs]=useState([]);const [res,setRes]=useState(RES);const [notice,setNotice]=useState("");async function login(){const r=await fetch(`${API}/api/teacher/login`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({passcode:pass})});if(r.ok){setOk(true);load()}else setNotice("Incorrect passcode.")}async function load(){const [a,b,c]=await Promise.all([fetch(`${API}/api/teacher/pupils`,{credentials:"include"}),fetch(`${API}/api/teacher/reflections`,{credentials:"include"}),fetch(`${API}/api/resources`)]);if(a.ok)setPupils(await a.json());if(b.ok)setRefs(await b.json());if(c.ok)setRes(await c.json())}async function fresh(){if(confirm("Start fresh and delete pupil progress and reflections?")){await fetch(`${API}/api/teacher/start-fresh`,{method:"POST",credentials:"include"});load()}}async function logout(){await fetch(`${API}/api/teacher/logout`,{method:"POST"});setOk(false)}if(!ok)return <div className="page"><div className="card teacher-login"><button onClick={onBack}>← Back</button><h1>Teacher's Mode 🔐</h1><p>Enter the teacher passcode.</p><input type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="Passcode"/><button className="primary" onClick={login}>Sign in</button><small>{notice}</small></div></div>;return <div className="page"><div className="teacher-head"><button onClick={onBack}>← Pupil View</button><button onClick={logout}>Log out</button></div><div className="teacher-grid"><section className="card"><h2>Class overview</h2><div className="stats"><div><b>{pupils.length}</b><small>Pupils</small></div><div><b>{pupils.reduce((a,p)=>a+(p.stars||0),0)}</b><small>Stars</small></div><div><b>{pupils.filter(p=>p.quiz).length}</b><small>Quizzes</small></div></div></section><section className="card"><h2>Performance</h2><div className="table-wrap"><table><thead><tr><th>Nickname</th><th>Stars</th><th>Quiz</th></tr></thead><tbody>{pupils.map(p=><tr key={p.nickname}><td>{p.nickname}</td><td>{p.stars||0}/7</td><td>{p.quiz?`${p.quiz.score}/${p.quiz.total}`:"—"}</td></tr>)}</tbody></table></div><a className="secondary-link" href={`${API}/api/teacher/export.csv`} target="_blank" rel="noreferrer">Export CSV</a></section><section className="card"><h2>Resource Manager</h2>{Object.entries(res).map(([k,v])=><label key={k}>{k}<input value={v} onChange={e=>setRes({...res,[k]:e.target.value})}/><button onClick={async()=>{await fetch(`${API}/api/resources/${k}`,{method:"PUT",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:res[k]})});setNotice("Saved.")}}>Save</button></label>)}</section><section className="card"><h2>Reflections</h2>{refs.slice(0,20).map((r,i)=><article className="reflection-row" key={i}><b>{r.nickname}</b><span>{r.mood}</span><p>{r.response}</p></article>)}</section><section className="card danger"><h2>Start Fresh</h2><p>Delete pupil progress and reflections. This cannot be undone.</p><button className="danger-btn" onClick={fresh}>Start Fresh</button></section></div></div>}
createRoot(document.getElementById("root")).render(<App/>);
