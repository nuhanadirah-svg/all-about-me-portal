# ALL ABOUT ME: English Learning Portal — Full Starter

A full-stack Year 5 English learning portal with a pastel 3D star-sky theme.

## Stack
- React + Vite
- Three.js
- FastAPI
- MongoDB
- JWT-style signed teacher tokens using itsdangerous

## Run
### Backend
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows
# or: cp .env.example .env
uvicorn main:app --reload --port 8000

### Frontend
cd frontend
npm install
npm run dev

The frontend defaults to http://localhost:5173 and calls http://localhost:8000.

## Background sound
The project intentionally ships with NO copyrighted audio file. Put your own royalty-free/owned MP3 at:
frontend/public/audio/aesthetic-background.mp3

The Settings panel has:
- Background Sound ON/OFF
- Volume slider
- Mute button in the top bar

Sound is OFF by default and only starts after the pupil presses the sound control, because browsers commonly block autoplay with audio.

## Important
- Use nicknames/first names only.
- Do not collect sensitive personal information.
- The teacher passcode is server-side only.
- Change the default passcode before deployment.
